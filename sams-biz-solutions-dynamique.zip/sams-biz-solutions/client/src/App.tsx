import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import BlogArticle from "./pages/BlogArticle";
import MentionsLegales from "./pages/MentionsLegales";
import CGV from "./pages/CGV";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import ReglementInterieur from "./pages/ReglementInterieur";
import RGPD from "./pages/RGPD";
import FormationCommerce from "./pages/FormationCommerce";
import FormationSoftSkills from "./pages/FormationSoftSkills";
import FormationProspection from "./pages/FormationProspection";
import FormationDevCommercial from "./pages/FormationDevCommercial";
import FormationClosingConsultants from "./pages/FormationClosingConsultants";
import FormationRelationClient from "./pages/FormationRelationClient";
import FormationOrganisation from "./pages/FormationOrganisation";
import FormationCommunication from "./pages/FormationCommunication";
import FormationIA from "./pages/FormationIA";
import FormationIAProductivite from "./pages/FormationIAProductivite";

import CookieConsent from "./components/CookieConsent";
import WhatsAppButton from "./components/WhatsAppButton";
import StickyBanner from "./components/StickyBanner";
import ExitIntentPopup from "./components/ExitIntentPopup";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/blog/:slug"} component={BlogArticle} />
      <Route path={"/mentions-legales"} component={MentionsLegales} />
      <Route path={"/cgv"} component={CGV} />
      <Route path={"/politique-confidentialite"} component={PolitiqueConfidentialite} />
      <Route path={"/reglement-interieur"} component={ReglementInterieur} />
      <Route path={"/rgpd"} component={RGPD} />
      {/* Formations existantes */}
      <Route path={"/formation/commerce-detail"} component={FormationCommerce} />
      <Route path={"/formation/soft-skills"} component={FormationSoftSkills} />
      <Route path={"/formation/prospection-closing"} component={FormationProspection} />
      {/* Nouvelles formations */}
      <Route path={"/formation/developpement-commercial"} component={FormationDevCommercial} />
      <Route path={"/formation/closing-consultants"} component={FormationClosingConsultants} />
      <Route path={"/formation/relation-client"} component={FormationRelationClient} />
      <Route path={"/formation/organisation-commerciale"} component={FormationOrganisation} />
      <Route path={"/formation/communication-equipe"} component={FormationCommunication} />
      <Route path={"/formation/ia-assistante-professionnelle"} component={FormationIA} />
      <Route path={"/formation/ia-productivite"} component={FormationIAProductivite} />

      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster 
            position="top-right"
            toastOptions={{
              style: {
                background: 'white',
                border: '1px solid oklch(0.90 0.005 90)',
              },
            }}
          />
          <StickyBanner />
          <Router />
          <CookieConsent />
          <WhatsAppButton />
          <ExitIntentPopup />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
