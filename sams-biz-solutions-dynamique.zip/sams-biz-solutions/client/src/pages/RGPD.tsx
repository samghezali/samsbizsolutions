/**
 * Page RGPD - Règlement Général sur la Protection des Données
 * Executive Minimalism Design
 */

import { useEffect } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, Shield, Lock, Eye, UserCheck, FileText, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function RGPD() {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = "RGPD | Sam's Biz Solutions";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-charcoal text-white py-16">
        <div className="container">
          <Button
            asChild
            variant="ghost"
            className="text-white/70 hover:text-white mb-6"
          >
            <Link href="/">
              <ArrowLeft size={18} className="mr-2" />
              Retour à l'accueil
            </Link>
          </Button>
          <div className="flex items-center gap-4 mb-4">
            <Shield size={40} className="text-gold" />
            <h1 className="font-display text-4xl font-bold">RGPD</h1>
          </div>
          <p className="text-white/70 text-lg">
            Règlement Général sur la Protection des Données
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-16">
        <div className="max-w-4xl mx-auto prose prose-lg">
          
          {/* Introduction */}
          <div className="bg-gold/10 border border-gold/20 rounded-xl p-6 mb-8">
            <p className="text-foreground m-0">
              <strong>Sam's Biz Solutions</strong> s'engage à protéger vos données personnelles conformément au 
              Règlement Général sur la Protection des Données (RGPD) - Règlement (UE) 2016/679 du 27 avril 2016.
            </p>
          </div>

          {/* Section 1 */}
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                <UserCheck size={20} className="text-gold" />
              </div>
              <h2 className="text-2xl font-display font-semibold m-0">1. Responsable du traitement</h2>
            </div>
            <p className="text-muted-foreground">
              Le responsable du traitement des données personnelles est :
            </p>
            <div className="bg-background border border-border rounded-lg p-4 mt-4">
              <p className="m-0"><strong>Samira GHEZALI</strong></p>
              <p className="m-0">Sam's Biz Solutions</p>
              <p className="m-0">20 rue Lavoisier, 95300 Pontoise</p>
              <p className="m-0">Email : sbizsolutions@outlook.fr</p>
              <p className="m-0">Téléphone : 06 66 38 31 07</p>
            </div>
          </div>

          {/* Section 2 */}
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                <FileText size={20} className="text-gold" />
              </div>
              <h2 className="text-2xl font-display font-semibold m-0">2. Données collectées</h2>
            </div>
            <p className="text-muted-foreground">
              Dans le cadre de nos activités de formation, nous collectons les données suivantes :
            </p>
            <ul className="text-muted-foreground space-y-2">
              <li><strong>Données d'identification :</strong> nom, prénom, fonction, entreprise</li>
              <li><strong>Coordonnées :</strong> adresse email, numéro de téléphone, adresse postale</li>
              <li><strong>Données professionnelles :</strong> poste occupé, secteur d'activité, besoins en formation</li>
              <li><strong>Données de navigation :</strong> cookies, adresse IP, pages visitées</li>
              <li><strong>Données de formation :</strong> évaluations, attestations, suivi pédagogique</li>
            </ul>
          </div>

          {/* Section 3 */}
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                <Eye size={20} className="text-gold" />
              </div>
              <h2 className="text-2xl font-display font-semibold m-0">3. Finalités du traitement</h2>
            </div>
            <p className="text-muted-foreground">
              Vos données personnelles sont collectées pour les finalités suivantes :
            </p>
            <ul className="text-muted-foreground space-y-2">
              <li>Gestion des demandes de contact et de diagnostic</li>
              <li>Établissement des devis et conventions de formation</li>
              <li>Organisation et suivi des formations</li>
              <li>Délivrance des attestations et certificats</li>
              <li>Facturation et gestion administrative</li>
              <li>Envoi de newsletters (avec votre consentement)</li>
              <li>Amélioration de nos services</li>
              <li>Respect de nos obligations légales (Qualiopi, OPCO)</li>
            </ul>
          </div>

          {/* Section 4 */}
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                <Lock size={20} className="text-gold" />
              </div>
              <h2 className="text-2xl font-display font-semibold m-0">4. Base légale du traitement</h2>
            </div>
            <p className="text-muted-foreground">
              Le traitement de vos données repose sur les bases légales suivantes :
            </p>
            <ul className="text-muted-foreground space-y-2">
              <li><strong>Exécution du contrat :</strong> pour la réalisation des prestations de formation</li>
              <li><strong>Consentement :</strong> pour l'envoi de newsletters et communications marketing</li>
              <li><strong>Obligation légale :</strong> pour la conservation des documents de formation (Qualiopi)</li>
              <li><strong>Intérêt légitime :</strong> pour l'amélioration de nos services</li>
            </ul>
          </div>

          {/* Section 5 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">5. Durée de conservation</h2>
            <p className="text-muted-foreground">
              Vos données sont conservées pendant les durées suivantes :
            </p>
            <ul className="text-muted-foreground space-y-2">
              <li><strong>Données de formation :</strong> 5 ans après la fin de la formation (obligation Qualiopi)</li>
              <li><strong>Données de facturation :</strong> 10 ans (obligation comptable)</li>
              <li><strong>Données de prospection :</strong> 3 ans après le dernier contact</li>
              <li><strong>Données de navigation :</strong> 13 mois maximum</li>
            </ul>
          </div>

          {/* Section 6 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">6. Vos droits</h2>
            <p className="text-muted-foreground">
              Conformément au RGPD, vous disposez des droits suivants :
            </p>
            <div className="grid sm:grid-cols-2 gap-4 mt-4">
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit d'accès</h4>
                <p className="text-sm text-muted-foreground m-0">Obtenir une copie de vos données personnelles</p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit de rectification</h4>
                <p className="text-sm text-muted-foreground m-0">Corriger des données inexactes ou incomplètes</p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit à l'effacement</h4>
                <p className="text-sm text-muted-foreground m-0">Demander la suppression de vos données</p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit à la portabilité</h4>
                <p className="text-sm text-muted-foreground m-0">Récupérer vos données dans un format structuré</p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit d'opposition</h4>
                <p className="text-sm text-muted-foreground m-0">Vous opposer au traitement de vos données</p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Droit de limitation</h4>
                <p className="text-sm text-muted-foreground m-0">Limiter le traitement de vos données</p>
              </div>
            </div>
          </div>

          {/* Section 7 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">7. Exercer vos droits</h2>
            <p className="text-muted-foreground">
              Pour exercer vos droits, vous pouvez nous contacter :
            </p>
            <div className="bg-gold/10 border border-gold/20 rounded-xl p-6 mt-4">
              <div className="flex items-center gap-3 mb-4">
                <Mail size={24} className="text-gold" />
                <div>
                  <p className="font-semibold text-foreground m-0">Par email</p>
                  <a href="mailto:sbizsolutions@outlook.fr" className="text-gold hover:underline">
                    sbizsolutions@outlook.fr
                  </a>
                </div>
              </div>
              <p className="text-muted-foreground m-0 text-sm">
                Nous répondrons à votre demande dans un délai maximum de 30 jours.
              </p>
            </div>
          </div>

          {/* Section 8 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">8. Sécurité des données</h2>
            <p className="text-muted-foreground">
              Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger 
              vos données personnelles contre tout accès non autorisé, modification, divulgation ou destruction :
            </p>
            <ul className="text-muted-foreground space-y-2">
              <li>Connexions sécurisées (HTTPS)</li>
              <li>Accès restreint aux données</li>
              <li>Mots de passe sécurisés</li>
              <li>Sauvegardes régulières</li>
            </ul>
          </div>

          {/* Section 9 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">9. Cookies</h2>
            <p className="text-muted-foreground">
              Notre site utilise des cookies pour améliorer votre expérience de navigation. 
              Pour plus d'informations, consultez notre{' '}
              <Link href="/politique-confidentialite" className="text-gold hover:underline">
                Politique de confidentialité
              </Link>.
            </p>
          </div>

          {/* Section 10 */}
          <div className="mb-10">
            <h2 className="text-2xl font-display font-semibold">10. Réclamation</h2>
            <p className="text-muted-foreground">
              Si vous estimez que le traitement de vos données personnelles constitue une violation du RGPD, 
              vous avez le droit d'introduire une réclamation auprès de la CNIL :
            </p>
            <div className="bg-background border border-border rounded-lg p-4 mt-4">
              <p className="m-0"><strong>Commission Nationale de l'Informatique et des Libertés (CNIL)</strong></p>
              <p className="m-0">3 Place de Fontenoy, TSA 80715</p>
              <p className="m-0">75334 Paris Cedex 07</p>
              <p className="m-0">
                Site web : <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-gold hover:underline">www.cnil.fr</a>
              </p>
            </div>
          </div>

          {/* Update date */}
          <div className="border-t border-border pt-8 mt-12">
            <p className="text-muted-foreground text-sm">
              Dernière mise à jour : 26 janvier 2025
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
