/**
 * Règlement Intérieur - Page légale obligatoire pour les organismes de formation
 */

import { useEffect } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft, Download, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function ReglementInterieur() {
  useEffect(() => {
    document.title = "Règlement Intérieur | Sam's Biz Solutions";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <Link href="/">
              <span className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 cursor-pointer">
                <ArrowLeft size={16} />
                Retour à l'accueil
              </span>
            </Link>

            <h1 className="text-4xl font-display font-bold text-foreground mb-4">
              Règlement Intérieur
            </h1>
            <p className="text-muted-foreground mb-8">
              Applicable aux formations dispensées par Sam's Biz Solutions
            </p>

            {/* Download button */}
            <div className="bg-gold/10 border border-gold/20 rounded-xl p-6 mb-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gold/20 rounded-lg flex items-center justify-center">
                  <FileText className="text-gold" size={24} />
                </div>
                <div>
                  <p className="font-medium text-foreground">Télécharger le règlement intérieur</p>
                  <p className="text-sm text-muted-foreground">Document PDF officiel</p>
                </div>
              </div>
              <Button asChild className="bg-gold hover:bg-gold-dark text-charcoal">
                <a href="/documents/reglement-interieur.pdf" target="_blank" rel="noopener noreferrer">
                  <Download size={16} className="mr-2" />
                  Télécharger le PDF
                </a>
              </Button>
            </div>

            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-foreground prose-p:text-muted-foreground">
              
              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 1 : Présentation et objectifs</h2>
                <p>
                  Sam's Biz Solutions, dirigée par Samira GHEZALI, propose des formations professionnelles 
                  dans un cadre bienveillant et respectueux. Ce règlement intérieur a pour but de définir 
                  les règles de fonctionnement, les droits et les obligations des participants afin 
                  d'assurer le bon déroulement des formations.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 2 : Engagements de Sam's Biz Solutions</h2>
                <p>Sam's Biz Solutions s'engage à :</p>
                <ol>
                  <li>Fournir des formations de qualité, adaptées aux besoins des participants.</li>
                  <li>Mettre à disposition les supports de formation nécessaires.</li>
                  <li>Respecter les horaires et le programme annoncé.</li>
                  <li>Assurer un environnement d'apprentissage sécurisé et inclusif.</li>
                </ol>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 3 : Engagements des participants</h2>
                <p>Les participants s'engagent à :</p>
                <ol>
                  <li>Respecter les horaires de formation et prévenir en cas d'absence ou de retard.</li>
                  <li>Adopter un comportement respectueux envers la formatrice et les autres participants.</li>
                  <li>Participer activement et contribuer à un climat d'apprentissage positif.</li>
                  <li>Ne pas enregistrer, diffuser ou modifier les contenus de formation sans autorisation.</li>
                </ol>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 4 : Règles de conduite</h2>
                <ol>
                  <li>Il est interdit de perturber le bon déroulement des formations par des comportements 
                      inappropriés (bruit, interruptions intempestives, etc.).</li>
                  <li>Les téléphones portables doivent être éteints ou en mode silencieux pendant les sessions.</li>
                  <li>Les participants sont invités à respecter les locaux et le matériel mis à leur disposition.</li>
                </ol>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 5 : Annulation et absences</h2>
                <ol>
                  <li>En cas d'annulation par le participant, les conditions de remboursement ou de report 
                      sont précisées dans le contrat de formation.</li>
                  <li>Les absences non justifiées peuvent entraîner l'exclusion de la formation sans remboursement.</li>
                </ol>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 6 : Hygiène et sécurité</h2>
                <ol>
                  <li>Les participants doivent respecter les consignes de sécurité et d'hygiène en vigueur 
                      dans les locaux de formation.</li>
                  <li>Tout incident ou risque doit être signalé immédiatement à la formatrice.</li>
                </ol>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 7 : Confidentialité</h2>
                <p>
                  Les échanges et les informations partagées pendant les formations sont confidentiels. 
                  Les participants s'engagent à ne pas les divulguer à des tiers sans accord préalable.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 8 : Modification du règlement</h2>
                <p>
                  Sam's Biz Solutions se réserve le droit de modifier ce règlement intérieur. 
                  Les participants en seront informés par écrit ou par courriel.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 9 : Acceptation du règlement</h2>
                <p>
                  En s'inscrivant à une formation dispensée par Sam's Biz Solutions, les participants 
                  acceptent sans réserve les termes du présent règlement intérieur.
                </p>
              </section>

              <div className="bg-white rounded-xl border border-border p-6 not-prose mt-12">
                <p className="font-medium text-foreground mb-2">Sam's Biz Solutions</p>
                <p className="text-muted-foreground">Samira GHEZALI, formatrice indépendante</p>
                <p className="text-muted-foreground">20 rue Lavoisier, 95300 Pontoise</p>
                <p className="text-muted-foreground">SIREN : 949 917 314 - RCS Pontoise</p>
                <p className="text-muted-foreground">N° Déclaration d'Activité : 11950911695</p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
