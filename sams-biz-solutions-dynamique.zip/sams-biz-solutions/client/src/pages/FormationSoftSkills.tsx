/**
 * Formation Soft Skills - Page dédiée conforme Qualiopi
 * Design: Executive Minimalism
 */

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { 
  Clock, 
  Users, 
  Euro, 
  CheckCircle2, 
  Target, 
  BookOpen, 
  Award,
  Calendar,
  Phone,
  ArrowLeft,
  Download,
  Accessibility,
  Heart,
  MessageCircle,
  Handshake,
  MapPin,
  ExternalLink
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FormationRegistrationForm from '@/components/FormationRegistrationForm';

const objectives = [
  "Comprendre l'importance des soft skills dans le monde professionnel",
  "Identifier les compétences relationnelles clés pour une entreprise",
  "Développer des techniques pour améliorer la communication, la collaboration et l'empathie",
  "Intégrer les soft skills dans la culture d'entreprise et les processus RH",
  "Mesurer l'impact des soft skills sur la performance individuelle et collective"
];

const programme = [
  {
    title: "Introduction aux Soft Skills",
    icon: Heart,
    content: [
      "Définition et enjeux des soft skills (compétences relationnelles, émotionnelles, sociales)",
      "Les différences entre hard skills et soft skills",
      "L'importance des soft skills dans un environnement professionnel en mutation",
      "Les tendances actuelles (travail en équipe, intelligence émotionnelle, agilité)"
    ]
  },
  {
    title: "Les Compétences Relationnelles Clés",
    icon: MessageCircle,
    content: [
      "La communication efficace (écoute active, feedback constructif)",
      "L'empathie et l'intelligence émotionnelle",
      "La collaboration et le travail d'équipe",
      "La gestion des conflits et la résolution de problèmes",
      "L'adaptabilité et la gestion du changement"
    ]
  },
  {
    title: "Développement des Soft Skills",
    icon: Target,
    content: [
      "Techniques pour améliorer la communication interpersonnelle",
      "Exercices pour renforcer l'empathie et la bienveillance",
      "Méthodes pour favoriser la collaboration et la cohésion d'équipe",
      "Stratégies pour gérer les conflits de manière constructive",
      "Outils pour développer l'adaptabilité et la résilience"
    ]
  },
  {
    title: "Intégration des Soft Skills dans l'Entreprise",
    icon: Handshake,
    content: [
      "Identifier les soft skills prioritaires pour l'entreprise",
      "Intégrer les soft skills dans les processus de recrutement et d'évaluation",
      "Créer un environnement de travail propice au développement des soft skills",
      "Former les managers à l'importance des soft skills",
      "Mesurer l'impact sur la performance et la satisfaction des collaborateurs"
    ]
  }
];

export default function FormationSoftSkills() {
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);

  useEffect(() => {
    document.title = "Formation Soft Skills | Sam's Biz Solutions";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-gradient-to-b from-gold/10 to-background">
          <div className="container">
            <Link href="/#formations">
              <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold transition-colors mb-8">
                <ArrowLeft size={18} />
                Retour aux formations
              </a>
            </Link>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 bg-gold/10 text-gold px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Award size={16} />
                Formation avec processus certifié Qualiopi
              </div>
              
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">
                Intégrer les Soft Skills dans<br />
                <span className="text-gold">son Environnement de Travail</span>
              </h1>
              
              <p className="text-lg text-muted-foreground max-w-2xl mb-8">
                Développez les compétences relationnelles et émotionnelles de vos équipes pour 
                améliorer la collaboration, la communication et la performance collective.
              </p>
              
              {/* Key Info Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Clock className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Durée</p>
                  <p className="font-semibold text-foreground">3 jours</p>
                  <p className="text-xs text-muted-foreground">ou 6 demi-journées</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Euro className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Tarif inter</p>
                  <p className="font-semibold text-foreground">À partir de 450€ HT</p>
                  <p className="text-xs text-muted-foreground">par stagiaire</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Users className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Public</p>
                  <p className="font-semibold text-foreground">Tout public</p>
                  <p className="text-xs text-muted-foreground">Aucun prérequis</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Calendar className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Modalité</p>
                  <p className="font-semibold text-foreground">Présentiel / Distanciel</p>
                  <p className="text-xs text-muted-foreground">Au choix</p>
                </div>
              </div>

              {/* Sessions sur mesure */}
              <div className="bg-gold/10 rounded-xl p-4 mb-8 border border-gold/20">
                <div className="flex items-center gap-3">
                  <Calendar className="text-gold" size={24} />
                  <div>
                    <p className="font-semibold text-foreground">Sessions sur mesure</p>
                    <p className="text-gold font-bold text-lg">Sessions sur mesure - Entrées et sorties permanentes</p>
                    <p className="text-sm text-muted-foreground mt-1">Places limitées à 14 apprenants</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsRegistrationOpen(true)}
                  className="text-sm text-gold hover:underline mt-2 inline-block font-medium"
                >
                  → Réserver ma place pour cette session
                </button>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-gold hover:bg-gold-dark text-charcoal font-semibold"
                  onClick={() => setIsRegistrationOpen(true)}
                >
                  <Calendar size={18} className="mr-2" />
                  Réserver ma place
                </Button>
                <Button asChild variant="outline" size="lg">
                  <a href="/documents/catalogue-formations.pdf" target="_blank" rel="noopener noreferrer">
                    <Download size={18} className="mr-2" />
                    Télécharger le programme
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Objectifs */}
        <section className="py-16 bg-white">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-6">
                <Target className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Objectifs pédagogiques</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                {objectives.map((objective, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-start gap-3 bg-background rounded-lg p-4"
                  >
                    <CheckCircle2 className="text-gold flex-shrink-0 mt-0.5" size={20} />
                    <span className="text-foreground">{objective}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Programme */}
        <section className="py-16 bg-background">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <BookOpen className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Programme détaillé</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {programme.map((module, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-border"
                  >
                    <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-3">
                      <span className="w-10 h-10 bg-gold/10 text-gold rounded-full flex items-center justify-center">
                        <module.icon size={20} />
                      </span>
                      {module.title}
                    </h3>
                    <ul className="space-y-2">
                      {module.content.map((item, itemIndex) => (
                        <li key={itemIndex} className="text-muted-foreground flex items-start gap-2">
                          <span className="text-gold mt-1.5">•</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Modalités */}
        <section className="py-16 bg-white">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              {/* Moyens pédagogiques */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Moyens pédagogiques</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Exercices pratiques
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Outils digitaux
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Support papier et paperboard
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Mises en situation
                  </li>
                </ul>
              </motion.div>

              {/* Évaluation */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Modalités d'évaluation</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Quiz théorique
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Évaluation avant, pendant et après
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Certificat de réussite
                  </li>
                </ul>
              </motion.div>

              {/* Suivi */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Suivi post-formation</h3>
                <p className="text-muted-foreground">
                  Plan d'action pour intégrer les soft skills au sein de l'équipe avec 
                  retour d'expérience 3 mois après la fin de la formation.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Lieu de formation */}
        <section className="py-16 bg-white">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <MapPin className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Lieu de formation</h2>
              </div>
              
              <div className="bg-background rounded-xl p-6 md:p-8 border border-border">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Espace Nikolsen</h3>
                    <p className="text-muted-foreground mb-4">
                      Salle de formation équipée pouvant accueillir jusqu'à 15 personnes, 
                      facile d'accès et idéalement située à Pontoise. Formation également disponible en distanciel via visioconférence.
                    </p>
                    <div className="space-y-2 mb-6">
                      <p className="text-foreground font-medium">20 rue Lavoisier</p>
                      <p className="text-foreground">95300 Pontoise</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <a 
                        href="https://fr.mappy.com/plan/95300-pontoise/20-rue-lavoisier" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-gold hover:bg-gold-dark text-charcoal font-semibold px-4 py-2 rounded-lg transition-colors"
                      >
                        <ExternalLink size={16} />
                        Itinéraire Mappy
                      </a>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-foreground">Équipements disponibles :</h4>
                    <ul className="space-y-2">
                      {[
                        'Vidéoprojecteur et écran',
                        'Paperboard et marqueurs',
                        'Connexion Wi-Fi haut débit',
                        'Climatisation / chauffage',
                        'Espace pause café',
                        'Accessibilité PMR'
                      ].map((item, index) => (
                        <li key={index} className="flex items-center gap-2 text-muted-foreground">
                          <CheckCircle2 className="text-gold flex-shrink-0" size={16} />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Accessibilité */}
        <section className="py-16 bg-gold/5">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-xl p-6 md:p-8 flex flex-col md:flex-row items-start gap-6"
            >
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Accessibility className="text-gold" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Accessibilité handicap</h3>
                <p className="text-muted-foreground mb-4">
                  Afin de respecter toutes les formes de handicap, nous aménageons, en partenariat avec vous 
                  et le lieu de dispense de la formation, les équipements permettant à chacun d'évoluer dans 
                  de bonnes conditions.
                </p>
                <p className="text-foreground font-medium">
                  Référente Handicap : Samira GHEZALI — 
                  <a href="tel:+33666383107" className="text-gold hover:underline ml-1">06 66 38 31 07</a>
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Merci de nous contacter 14 jours avant la formation.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-charcoal text-white">
          <div className="container text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-2xl md:text-3xl font-display font-bold mb-4">
                Prêt à développer les soft skills de vos équipes ?
              </h2>
              <p className="text-white/70 mb-8 max-w-xl mx-auto">
                Réservez votre diagnostic offert pour vérifier votre éligibilité au financement OPCO 
                et obtenir un devis personnalisé.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-gold hover:bg-gold-dark text-charcoal font-semibold"
                  onClick={() => setIsRegistrationOpen(true)}
                >
                  Réserver ma place à cette formation
                </Button>
                <Button asChild variant="outline" size="lg" className="border-white/30 text-white hover:bg-white/10">
                  <a href="tel:+33666383107">
                    <Phone size={18} className="mr-2" />
                    06 66 38 31 07
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Modal d'inscription */}
      <FormationRegistrationForm
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
        formationName="Soft Skills"
        sessionDate="Sessions sur mesure"
      />
    </div>
  );
}
