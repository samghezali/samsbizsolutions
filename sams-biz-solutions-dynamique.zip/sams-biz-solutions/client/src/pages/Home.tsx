/**
 * Home Page - Sam's Biz Solutions
 * Executive Minimalism Design - Complete landing page
 * 
 * SEO Keywords (5 targeted): formation Qualiopi Pontoise, formation commerciale,
 * leadership entreprise, financement OPCO, soft skills
 * 
 * Design Philosophy:
 * - Swiss Design / Corporate Minimalism with subtle luxury
 * - Gold accents (#B8860B) on cream background (#FAFAFA)
 * - Playfair Display for headings, Source Sans Pro for body
 * - Generous whitespace and elegant transitions
 */

import { useEffect } from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import ServicesSection from '@/components/ServicesSection';
import DifferenceSection from '@/components/DifferenceSection';
import QualiopiSection from '@/components/QualiopiSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import NotificationBanner from '@/components/NotificationBanner';
import BlogSection from '@/components/BlogSection';
import FAQSection from '@/components/FAQSection';
import ZonesInterventionSection from '@/components/ZonesInterventionSection';
import KineticBand from '@/components/KineticBand';

export default function Home() {
  // SEO: Set document title dynamically (50 characters - optimal for SEO)
  useEffect(() => {
    document.title = "Formation Commerciale Qualiopi | Val-d'Oise, Oise, Île-de-France | Sam's Biz Solutions";
    
    // Update meta description (155 characters - within 50-160 range)
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 
        "Organisme de formation commerciale avec processus certifié Qualiopi à Pontoise, Cergy, Beauvais, Gisors. Formation OPCO finançable en Val-d'Oise, Oise et Île-de-France. Soft skills, vente, leadership."
      );
    }
    
    // Update meta keywords (5 targeted keywords)
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', 
      "formation commerciale Beauvais, formation OPCO Gisors, organisme formation Qualiopi Oise, formation vente Val-d'Oise, formation soft skills Cergy"
    );
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Notification Banner */}
      <NotificationBanner />
      
      <Header />
      <main>
        <HeroSection />
        <KineticBand />
        <AboutSection />
        <ServicesSection />
        <ZonesInterventionSection />
        <DifferenceSection />
        <QualiopiSection />
        <TestimonialsSection />
        <BlogSection />
        <FAQSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
