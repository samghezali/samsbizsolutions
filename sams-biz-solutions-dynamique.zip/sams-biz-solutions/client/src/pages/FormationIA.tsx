/**
 * Formation IA Assistante Professionnelle - Page dédiée conforme Qualiopi
 * Design: Executive Minimalism
 */

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { 
  Clock, 
  Users, 
  Euro, 
  CheckCircle2, 
  Target, 
  BookOpen, 
  Award,
  Calendar,
  Phone,
  ArrowLeft,
  Download,
  Accessibility,
  Cpu,
  FileText,
  Zap,
  Settings,
  MapPin,
  ExternalLink
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FormationRegistrationForm from '@/components/FormationRegistrationForm';

const objectives = [
  "Comprendre les usages concrets de l'IA dans un contexte professionnel",
  "Utiliser l'IA pour structurer l'information et produire des contenus de qualité",
  "Déléguer les tâches chronophages à des outils d'IA adaptés",
  "Automatiser les processus répétitifs pour gagner en productivité",
  "Optimiser l'organisation du travail grâce aux assistants intelligents"
];

const programme = [
  {
    title: "Comprendre l'IA au service du professionnel",
    icon: Cpu,
    content: [
      "Panorama des outils d'IA disponibles (ChatGPT, Copilot, Gemini, etc.)",
      "Distinguer les usages pertinents des gadgets inutiles",
      "Identifier les tâches délégables à l'IA dans son quotidien",
      "Les limites et les bonnes pratiques d'utilisation"
    ]
  },
  {
    title: "Structurer et produire des contenus professionnels",
    icon: FileText,
    content: [
      "Rédiger des emails, comptes-rendus et rapports avec l'IA",
      "Créer des présentations et supports visuels assistés",
      "Synthétiser des documents longs en quelques secondes",
      "Adapter le ton et le style selon le contexte professionnel"
    ]
  },
  {
    title: "Automatiser les tâches chronophages",
    icon: Zap,
    content: [
      "Automatiser la veille et la recherche d'informations",
      "Gérer son agenda et ses priorités avec l'IA",
      "Créer des workflows automatisés simples",
      "Traiter et analyser des données sans compétences techniques"
    ]
  },
  {
    title: "Optimiser son organisation de travail",
    icon: Settings,
    content: [
      "Intégrer l'IA dans sa routine professionnelle quotidienne",
      "Construire son propre kit d'outils IA personnalisé",
      "Mesurer les gains de temps et de productivité",
      "Plan d'action individuel pour la mise en pratique"
    ]
  }
];

export default function FormationIA() {
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);

  useEffect(() => {
    document.title = "Formation IA Professionnelle | Sam's Biz";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-gradient-to-b from-gold/10 to-background">
          <div className="container">
            <Link href="/#formations">
              <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold transition-colors mb-8">
                <ArrowLeft size={18} />
                Retour aux formations
              </a>
            </Link>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 bg-gold/10 text-gold px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Award size={16} />
                Formation avec processus certifié Qualiopi
              </div>
              
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">
                L'IA, votre assistante<br />
                <span className="text-gold">professionnelle au quotidien</span>
              </h1>
              
              <p className="text-lg text-muted-foreground max-w-2xl mb-8">
                Découvrez concrètement comment utiliser l'intelligence artificielle pour gagner du temps, 
                structurer l'information, produire des contenus professionnels et optimiser 
                l'organisation de votre travail.
              </p>
              
              {/* Key Info Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Clock className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Durée</p>
                  <p className="font-semibold text-foreground">2 jours</p>
                  <p className="text-xs text-muted-foreground">14 heures</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Euro className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Tarif inter</p>
                  <p className="font-semibold text-foreground">À partir de 450€ HT</p>
                  <p className="text-xs text-muted-foreground">par stagiaire</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Users className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Public</p>
                  <p className="font-semibold text-foreground">Tout professionnel</p>
                  <p className="text-xs text-muted-foreground">Aucun prérequis technique</p>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm border border-border">
                  <Calendar className="text-gold mb-2" size={24} />
                  <p className="text-sm text-muted-foreground">Modalité</p>
                  <p className="font-semibold text-foreground">Présentiel / Distanciel</p>
                  <p className="text-xs text-muted-foreground">Au choix</p>
                </div>
              </div>

              {/* Sessions sur mesure */}
              <div className="bg-gold/10 rounded-xl p-4 mb-8 border border-gold/20">
                <div className="flex items-center gap-3">
                  <Calendar className="text-gold" size={24} />
                  <div>
                    <p className="font-semibold text-foreground">Sessions sur mesure</p>
                    <p className="text-gold font-bold text-lg">Entrées et sorties permanentes toute l'année</p>
                    <p className="text-sm text-muted-foreground mt-1">Places limitées à 14 apprenants</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsRegistrationOpen(true)}
                  className="text-sm text-gold hover:underline mt-2 inline-block font-medium"
                >
                  → Réserver ma place pour cette session
                </button>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-gold hover:bg-gold-dark text-charcoal font-semibold"
                  onClick={() => setIsRegistrationOpen(true)}
                >
                  <Calendar size={18} className="mr-2" />
                  Réserver ma place
                </Button>
                <Button asChild variant="outline" size="lg">
                  <a href="/documents/catalogue-formations.pdf" target="_blank" rel="noopener noreferrer">
                    <Download size={18} className="mr-2" />
                    Télécharger le programme
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Objectifs */}
        <section className="py-16 bg-white">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-6">
                <Target className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Objectifs pédagogiques</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                {objectives.map((objective, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-start gap-3 bg-background rounded-lg p-4"
                  >
                    <CheckCircle2 className="text-gold flex-shrink-0 mt-0.5" size={20} />
                    <span className="text-foreground">{objective}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Programme */}
        <section className="py-16 bg-background">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <BookOpen className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Programme détaillé — 2 jours</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {programme.map((module, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-border"
                  >
                    <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-3">
                      <span className="w-10 h-10 bg-gold/10 text-gold rounded-full flex items-center justify-center">
                        <module.icon size={20} />
                      </span>
                      {module.title}
                    </h3>
                    <ul className="space-y-2">
                      {module.content.map((item, itemIndex) => (
                        <li key={itemIndex} className="text-muted-foreground flex items-start gap-2">
                          <span className="text-gold mt-1.5">•</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Modalités */}
        <section className="py-16 bg-white">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              {/* Moyens pédagogiques */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Moyens pédagogiques</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Démonstrations en direct sur outils IA
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Ateliers pratiques sur poste informatique
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Cas concrets issus du quotidien professionnel
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Support de formation et fiches outils
                  </li>
                </ul>
              </motion.div>

              {/* Évaluation */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Modalités d'évaluation</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Quiz de positionnement initial
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Exercices pratiques évalués
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Évaluation avant, pendant et après
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 size={16} className="text-gold" />
                    Attestation de formation
                  </li>
                </ul>
              </motion.div>

              {/* Suivi */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-background rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Suivi post-formation</h3>
                <p className="text-muted-foreground">
                  Kit d'outils IA personnalisé remis à chaque participant avec 
                  suivi de mise en pratique et retour d'expérience à 1 mois.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Lieu de formation */}
        <section className="py-16 bg-white">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <MapPin className="text-gold" size={28} />
                <h2 className="text-2xl font-display font-bold text-foreground">Lieu de formation</h2>
              </div>
              
              <div className="bg-background rounded-xl p-6 md:p-8 border border-border">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Espace Nikolsen</h3>
                    <p className="text-muted-foreground mb-4">
                      Salle de formation équipée pouvant accueillir jusqu'à 15 personnes, 
                      facile d'accès et idéalement située à Pontoise. Formation également 
                      disponible en distanciel via visioconférence.
                    </p>
                    <div className="space-y-2 mb-6">
                      <p className="text-foreground font-medium">20 rue Lavoisier</p>
                      <p className="text-foreground">95300 PONTOISE</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <a 
                        href="https://fr.mappy.com/plan/95300-pontoise/20-rue-lavoisier" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-gold hover:bg-gold-dark text-charcoal font-semibold px-4 py-2 rounded-lg transition-colors"
                      >
                        <ExternalLink size={16} />
                        Itinéraire Mappy
                      </a>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-foreground">Équipements disponibles :</h4>
                    <ul className="space-y-2">
                      {[
                        'Vidéoprojecteur et écran',
                        'Paperboard et marqueurs',
                        'Connexion Wi-Fi haut débit',
                        'Climatisation / chauffage',
                        'Espace pause café',
                        'Accessibilité PMR'
                      ].map((item, index) => (
                        <li key={index} className="flex items-center gap-2 text-muted-foreground">
                          <CheckCircle2 className="text-gold flex-shrink-0" size={16} />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Accessibilité */}
        <section className="py-16 bg-gold/5">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-xl p-6 md:p-8 flex flex-col md:flex-row items-start gap-6"
            >
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Accessibility className="text-gold" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Accessibilité handicap</h3>
                <p className="text-muted-foreground mb-4">
                  Afin de respecter toutes les formes de handicap, nous aménageons, en partenariat avec vous 
                  et le lieu de dispense de la formation, les équipements permettant à chacun d'évoluer dans 
                  de bonnes conditions.
                </p>
                <p className="text-foreground font-medium">
                  Référente Handicap : Samira GHEZALI — 
                  <a href="tel:+33666383107" className="text-gold hover:underline ml-1">06 66 38 31 07</a>
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Merci de nous contacter 14 jours avant la formation.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-charcoal text-white">
          <div className="container text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-2xl md:text-3xl font-display font-bold mb-4">
                Transformez l'IA en alliée de votre productivité
              </h2>
              <p className="text-white/70 mb-8 max-w-xl mx-auto">
                Réservez votre diagnostic offert pour vérifier votre éligibilité au financement OPCO 
                et obtenir un devis personnalisé.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-gold hover:bg-gold-dark text-charcoal font-semibold"
                  onClick={() => setIsRegistrationOpen(true)}
                >
                  Réserver ma place à cette formation
                </Button>
                <Button asChild variant="outline" size="lg" className="border-white/30 text-white hover:bg-white/10">
                  <a href="tel:+33666383107">
                    <Phone size={18} className="mr-2" />
                    06 66 38 31 07
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Modal d'inscription */}
      <FormationRegistrationForm
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
        formationName="IA Assistante Professionnelle"
        sessionDate="Sessions sur mesure"
      />
    </div>
  );
}
