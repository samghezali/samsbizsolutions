/**
 * Conditions Générales de Vente - Page légale obligatoire
 * Adaptées à un organisme de formation avec processus certifié Qualiopi
 */

import { useEffect } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function CGV() {
  useEffect(() => {
    document.title = "Conditions Générales de Vente | Sam's Biz Solutions";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <Link href="/">
              <span className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 cursor-pointer">
                <ArrowLeft size={16} />
                Retour à l'accueil
              </span>
            </Link>

            <h1 className="text-4xl font-display font-bold text-foreground mb-4">
              Conditions Générales de Vente
            </h1>
            <p className="text-muted-foreground mb-8">
              Applicables aux prestations de formation professionnelle
            </p>

            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-foreground prose-p:text-muted-foreground">
              
              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 1 : Objet et champ d'application</h2>
                <p>
                  Les présentes Conditions Générales de Vente (CGV) s'appliquent à toutes les prestations 
                  de formation professionnelle conclues par Sam's Biz Solutions, organisme de formation 
                  avec processus certifié Qualiopi, auprès de ses clients professionnels.
                </p>
                <p>
                  Toute commande de formation implique l'acceptation sans réserve des présentes CGV.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 2 : Identification de l'organisme</h2>
                <div className="bg-white rounded-xl border border-border p-6 not-prose mb-4">
                  <table className="w-full text-left">
                    <tbody className="divide-y divide-border">
                      <tr>
                        <td className="py-3 font-medium text-foreground w-1/3">Organisme</td>
                        <td className="py-3 text-muted-foreground">Sam's Biz Solutions</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Dirigeante</td>
                        <td className="py-3 text-muted-foreground">Samira GHEZALI</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Adresse</td>
                        <td className="py-3 text-muted-foreground">20 rue Lavoisier, 95300 Pontoise</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">SIREN</td>
                        <td className="py-3 text-muted-foreground">949 917 314</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">N° Déclaration d'Activité</td>
                        <td className="py-3 text-muted-foreground">11950911695</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Certification Qualiopi</td>
                        <td className="py-3 text-muted-foreground">N° QUA008437 - Actions de formation</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 3 : Inscription et convention de formation</h2>
                <p>
                  <strong>3.1</strong> Toute demande de formation fait l'objet d'un devis gratuit et personnalisé, 
                  établi après un entretien de diagnostic permettant d'évaluer les besoins du client.
                </p>
                <p>
                  <strong>3.2</strong> L'inscription est considérée comme définitive à réception du devis signé 
                  et/ou de la convention de formation signée, accompagnée le cas échéant de l'accord de 
                  prise en charge de l'OPCO.
                </p>
                <p>
                  <strong>3.3</strong> Une convocation est adressée au participant au plus tard 7 jours avant 
                  le début de la formation, précisant les informations pratiques (lieu, horaires, programme).
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 4 : Tarifs et modalités de paiement</h2>
                <p>
                  <strong>4.1</strong> Les tarifs des formations sont indiqués en euros hors taxes (HT). 
                  Sam's Biz Solutions n'est pas assujettie à la TVA au titre de la formation professionnelle 
                  (article 261-4-4° du CGI).
                </p>
                <p>
                  <strong>4.2</strong> Le règlement s'effectue selon les modalités suivantes :
                </p>
                <ul>
                  <li>Par virement bancaire à 30 jours fin de mois</li>
                  <li>Par chèque à l'ordre de Sam's Biz Solutions</li>
                  <li>Par prise en charge OPCO (sur présentation de l'accord)</li>
                </ul>
                <p>
                  <strong>4.3</strong> En cas de prise en charge partielle par l'OPCO, le solde est facturé 
                  directement au client.
                </p>
                <p>
                  <strong>4.4</strong> Tout retard de paiement entraîne l'application de pénalités de retard 
                  égales à 3 fois le taux d'intérêt légal, ainsi qu'une indemnité forfaitaire de 40€ pour 
                  frais de recouvrement.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 5 : Annulation et report</h2>
                <p>
                  <strong>5.1 Annulation par le client :</strong>
                </p>
                <ul>
                  <li>Plus de 15 jours avant le début de la formation : aucun frais</li>
                  <li>Entre 7 et 15 jours : 50% du montant de la formation</li>
                  <li>Moins de 7 jours : 100% du montant de la formation</li>
                </ul>
                <p>
                  <strong>5.2</strong> Le remplacement d'un participant par un autre est possible sans frais, 
                  sous réserve d'en informer Sam's Biz Solutions au moins 48 heures avant le début de la formation.
                </p>
                <p>
                  <strong>5.3 Annulation par Sam's Biz Solutions :</strong> En cas de force majeure ou de 
                  nombre insuffisant de participants, Sam's Biz Solutions se réserve le droit d'annuler 
                  ou de reporter la formation. Le client sera informé au moins 7 jours avant et pourra 
                  choisir entre un report ou un remboursement intégral.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 6 : Déroulement des formations</h2>
                <p>
                  <strong>6.1</strong> Les formations se déroulent selon le programme communiqué au préalable. 
                  Sam's Biz Solutions se réserve le droit d'adapter le contenu en fonction des besoins 
                  identifiés pendant la formation.
                </p>
                <p>
                  <strong>6.2</strong> Les horaires de formation sont généralement de 9h00 à 12h30 et de 
                  14h00 à 17h30, sauf indication contraire dans la convocation.
                </p>
                <p>
                  <strong>6.3</strong> Une feuille d'émargement est signée par les participants et le 
                  formateur pour chaque demi-journée de formation.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 7 : Évaluation et attestation</h2>
                <p>
                  <strong>7.1</strong> Les acquis des participants sont évalués en cours et/ou en fin de 
                  formation selon les modalités définies dans le programme.
                </p>
                <p>
                  <strong>7.2</strong> Une attestation de fin de formation mentionnant les objectifs, la 
                  durée et les résultats de l'évaluation est remise à chaque participant.
                </p>
                <p>
                  <strong>7.3</strong> Un questionnaire de satisfaction est proposé à l'issue de chaque formation.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 8 : Propriété intellectuelle</h2>
                <p>
                  Les supports de formation remis aux participants sont la propriété exclusive de 
                  Sam's Biz Solutions. Toute reproduction, diffusion ou utilisation à des fins commerciales 
                  est strictement interdite sans autorisation écrite préalable.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 9 : Responsabilité</h2>
                <p>
                  <strong>9.1</strong> Sam's Biz Solutions s'engage à mettre en œuvre tous les moyens 
                  nécessaires à la bonne exécution des formations. Il s'agit d'une obligation de moyens.
                </p>
                <p>
                  <strong>9.2</strong> La responsabilité de Sam's Biz Solutions ne saurait être engagée 
                  en cas de dommages indirects résultant de la formation.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 10 : Accessibilité</h2>
                <p>
                  Sam's Biz Solutions s'engage à rendre ses formations accessibles aux personnes en 
                  situation de handicap. Pour toute demande d'adaptation, contactez notre référente 
                  handicap : Samira GHEZALI au 06 66 38 31 07.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 11 : Règlement intérieur</h2>
                <p>
                  Les participants s'engagent à respecter le règlement intérieur de Sam's Biz Solutions, 
                  consultable sur ce site et remis avant le début de chaque formation.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 12 : Protection des données</h2>
                <p>
                  Les données personnelles collectées dans le cadre des formations sont traitées 
                  conformément au RGPD. Pour plus d'informations, consultez notre{' '}
                  <Link href="/politique-confidentialite" className="text-gold hover:underline">
                    Politique de Confidentialité
                  </Link>.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">Article 13 : Litiges</h2>
                <p>
                  En cas de litige, les parties s'engagent à rechercher une solution amiable. 
                  À défaut, les tribunaux de Pontoise seront seuls compétents.
                </p>
              </section>

              <p className="text-sm text-muted-foreground mt-12">
                Dernière mise à jour : Janvier 2025
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
