/**
 * Politique de Confidentialité - Page légale obligatoire RGPD
 */

import { useEffect } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function PolitiqueConfidentialite() {
  useEffect(() => {
    document.title = "Politique de Confidentialité | Sam's Biz Solutions";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <Link href="/">
              <span className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 cursor-pointer">
                <ArrowLeft size={16} />
                Retour à l'accueil
              </span>
            </Link>

            <h1 className="text-4xl font-display font-bold text-foreground mb-4">
              Politique de Confidentialité
            </h1>
            <p className="text-muted-foreground mb-8">
              Protection de vos données personnelles conformément au RGPD
            </p>

            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-foreground prose-p:text-muted-foreground">
              
              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">1. Responsable du traitement</h2>
                <p>
                  Le responsable du traitement des données personnelles est :
                </p>
                <div className="bg-white rounded-xl border border-border p-6 not-prose mb-4">
                  <p className="text-foreground font-medium">Sam's Biz Solutions</p>
                  <p className="text-muted-foreground">Samira GHEZALI</p>
                  <p className="text-muted-foreground">20 rue Lavoisier, 95300 Pontoise</p>
                  <p className="text-muted-foreground">Email : sbizsolutions@outlook.fr</p>
                  <p className="text-muted-foreground">Téléphone : 06 66 38 31 07</p>
                </div>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">2. Données collectées</h2>
                <p>
                  Dans le cadre de notre activité de formation professionnelle, nous collectons les 
                  données suivantes :
                </p>
                <ul>
                  <li><strong>Données d'identification :</strong> nom, prénom, fonction, entreprise</li>
                  <li><strong>Coordonnées :</strong> adresse email, numéro de téléphone, adresse postale</li>
                  <li><strong>Données professionnelles :</strong> poste occupé, besoins en formation</li>
                  <li><strong>Données de connexion :</strong> adresse IP, cookies (mesure d'audience)</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">3. Finalités du traitement</h2>
                <p>
                  Vos données personnelles sont collectées pour les finalités suivantes :
                </p>
                <ul>
                  <li>Gestion des demandes de contact et de diagnostic</li>
                  <li>Établissement des devis et conventions de formation</li>
                  <li>Organisation et suivi des formations</li>
                  <li>Facturation et gestion des prises en charge OPCO</li>
                  <li>Envoi d'informations sur nos formations (avec votre consentement)</li>
                  <li>Amélioration de nos services et de notre site web</li>
                  <li>Respect de nos obligations légales et réglementaires</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">4. Base légale du traitement</h2>
                <p>
                  Le traitement de vos données repose sur :
                </p>
                <ul>
                  <li><strong>L'exécution d'un contrat :</strong> pour la gestion des formations</li>
                  <li><strong>Le consentement :</strong> pour l'envoi de communications commerciales</li>
                  <li><strong>L'intérêt légitime :</strong> pour l'amélioration de nos services</li>
                  <li><strong>Les obligations légales :</strong> pour la conservation des documents comptables</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">5. Destinataires des données</h2>
                <p>
                  Vos données peuvent être transmises à :
                </p>
                <ul>
                  <li>Votre OPCO (pour les demandes de prise en charge)</li>
                  <li>Notre hébergeur web (Manus)</li>
                  <li>Nos outils de gestion (facturation, emailing)</li>
                  <li>Les autorités compétentes (sur demande légale)</li>
                </ul>
                <p>
                  Nous ne vendons ni ne louons vos données personnelles à des tiers.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">6. Durée de conservation</h2>
                <p>
                  Vos données sont conservées pendant les durées suivantes :
                </p>
                <ul>
                  <li><strong>Données clients :</strong> 5 ans après la dernière formation</li>
                  <li><strong>Documents comptables :</strong> 10 ans (obligation légale)</li>
                  <li><strong>Données de prospection :</strong> 3 ans après le dernier contact</li>
                  <li><strong>Cookies :</strong> 13 mois maximum</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">7. Vos droits</h2>
                <p>
                  Conformément au RGPD, vous disposez des droits suivants :
                </p>
                <ul>
                  <li><strong>Droit d'accès :</strong> obtenir une copie de vos données</li>
                  <li><strong>Droit de rectification :</strong> corriger des données inexactes</li>
                  <li><strong>Droit à l'effacement :</strong> demander la suppression de vos données</li>
                  <li><strong>Droit à la limitation :</strong> restreindre le traitement de vos données</li>
                  <li><strong>Droit à la portabilité :</strong> récupérer vos données dans un format structuré</li>
                  <li><strong>Droit d'opposition :</strong> vous opposer au traitement de vos données</li>
                  <li><strong>Droit de retrait du consentement :</strong> à tout moment pour les traitements basés sur le consentement</li>
                </ul>
                <p>
                  Pour exercer ces droits, contactez-nous à : <strong>sbizsolutions@outlook.fr</strong>
                </p>
                <p>
                  Vous pouvez également introduire une réclamation auprès de la CNIL : 
                  <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-gold hover:underline"> www.cnil.fr</a>
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">8. Cookies</h2>
                <p>
                  Notre site utilise des cookies pour :
                </p>
                <ul>
                  <li><strong>Cookies essentiels :</strong> fonctionnement du site</li>
                  <li><strong>Cookies analytiques :</strong> mesure d'audience (anonymisée)</li>
                </ul>
                <p>
                  Vous pouvez configurer votre navigateur pour refuser les cookies ou être alerté 
                  lors de leur utilisation.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">9. Sécurité des données</h2>
                <p>
                  Nous mettons en œuvre des mesures techniques et organisationnelles appropriées 
                  pour protéger vos données contre tout accès non autorisé, modification, divulgation 
                  ou destruction.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">10. Modifications</h2>
                <p>
                  Cette politique de confidentialité peut être mise à jour. Nous vous informerons 
                  de tout changement significatif par email ou via notre site web.
                </p>
              </section>

              <p className="text-sm text-muted-foreground mt-12">
                Dernière mise à jour : Janvier 2025
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
