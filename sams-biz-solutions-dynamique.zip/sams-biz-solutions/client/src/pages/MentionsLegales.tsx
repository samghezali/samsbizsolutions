/**
 * Mentions Légales - Page légale obligatoire
 * Conforme aux exigences françaises
 */

import { useEffect } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function MentionsLegales() {
  useEffect(() => {
    document.title = "Mentions Légales | Sam's Biz Solutions";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <Link href="/">
              <span className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 cursor-pointer">
                <ArrowLeft size={16} />
                Retour à l'accueil
              </span>
            </Link>

            <h1 className="text-4xl font-display font-bold text-foreground mb-8">
              Mentions Légales
            </h1>

            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-foreground prose-p:text-muted-foreground">
              
              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">1. Éditeur du site</h2>
                <div className="bg-white rounded-xl border border-border p-6 not-prose">
                  <table className="w-full text-left">
                    <tbody className="divide-y divide-border">
                      <tr>
                        <td className="py-3 font-medium text-foreground w-1/3">Raison sociale</td>
                        <td className="py-3 text-muted-foreground">Sam's Biz Solutions</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Statut</td>
                        <td className="py-3 text-muted-foreground">Entreprise individuelle</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Dirigeante</td>
                        <td className="py-3 text-muted-foreground">Samira GHEZALI</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Adresse</td>
                        <td className="py-3 text-muted-foreground">20 rue Lavoisier, 95300 Pontoise</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">SIREN</td>
                        <td className="py-3 text-muted-foreground">949 917 314</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">RCS</td>
                        <td className="py-3 text-muted-foreground">Pontoise</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">N° Déclaration d'Activité</td>
                        <td className="py-3 text-muted-foreground">11950911695 (Préfecture Île-de-France)</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Certification</td>
                        <td className="py-3 text-muted-foreground">Qualiopi - N° QUA008437</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Email</td>
                        <td className="py-3 text-muted-foreground">sbizsolutions@outlook.fr</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Téléphone</td>
                        <td className="py-3 text-muted-foreground">06 66 38 31 07</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">2. Directrice de la publication</h2>
                <p>
                  La directrice de la publication est Madame Samira GHEZALI, en sa qualité de dirigeante de Sam's Biz Solutions.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">3. Hébergement</h2>
                <div className="bg-white rounded-xl border border-border p-6 not-prose">
                  <table className="w-full text-left">
                    <tbody className="divide-y divide-border">
                      <tr>
                        <td className="py-3 font-medium text-foreground w-1/3">Hébergeur</td>
                        <td className="py-3 text-muted-foreground">Manus</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-medium text-foreground">Site web</td>
                        <td className="py-3 text-muted-foreground">https://manus.im</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">4. Propriété intellectuelle</h2>
                <p>
                  L'ensemble des contenus présents sur ce site (textes, images, logos, vidéos, graphismes, etc.) 
                  sont la propriété exclusive de Sam's Biz Solutions ou de leurs auteurs respectifs et sont 
                  protégés par les lois françaises et internationales relatives à la propriété intellectuelle.
                </p>
                <p>
                  Toute reproduction, représentation, modification, publication, adaptation de tout ou partie 
                  des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf 
                  autorisation écrite préalable de Sam's Biz Solutions.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">5. Protection des données personnelles</h2>
                <p>
                  Conformément au Règlement Général sur la Protection des Données (RGPD) et à la loi 
                  Informatique et Libertés, vous disposez d'un droit d'accès, de rectification, de suppression 
                  et d'opposition aux données personnelles vous concernant.
                </p>
                <p>
                  Pour exercer ces droits ou pour toute question relative à la protection de vos données, 
                  vous pouvez nous contacter à : <strong>sbizsolutions@outlook.fr</strong>
                </p>
                <p>
                  Pour plus d'informations, consultez notre <Link href="/politique-confidentialite" className="text-gold hover:underline">Politique de Confidentialité</Link>.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">6. Cookies</h2>
                <p>
                  Ce site utilise des cookies à des fins de mesure d'audience et d'amélioration de l'expérience 
                  utilisateur. En poursuivant votre navigation, vous acceptez l'utilisation de ces cookies.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">7. Limitation de responsabilité</h2>
                <p>
                  Sam's Biz Solutions s'efforce de fournir des informations aussi précises que possible. 
                  Toutefois, elle ne pourra être tenue responsable des omissions, des inexactitudes et des 
                  carences dans la mise à jour, qu'elles soient de son fait ou du fait des tiers partenaires 
                  qui lui fournissent ces informations.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-semibold mb-4">8. Droit applicable</h2>
                <p>
                  Les présentes mentions légales sont régies par le droit français. En cas de litige, 
                  les tribunaux français seront seuls compétents.
                </p>
              </section>

              <p className="text-sm text-muted-foreground mt-12">
                Dernière mise à jour : Janvier 2025
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
