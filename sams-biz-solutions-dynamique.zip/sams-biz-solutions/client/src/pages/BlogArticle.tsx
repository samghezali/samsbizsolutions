/**
 * Blog Article Page - Individual article view
 * Executive Minimalism Design
 */

import { useEffect } from 'react';
import { useParams, Link } from 'wouter';
import { motion } from 'framer-motion';
import { Calendar, Clock, ArrowLeft, User, Share2, Linkedin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// Article content for "techniques-vente-modernes-2025"
const articleContent = {
  id: 'techniques-vente-modernes-2025',
  title: '5 techniques de vente modernes qui fonctionnent vraiment en 2025',
  subtitle: 'Oubliez les scripts robotiques et les techniques de manipulation. Découvrez les approches qui créent de vraies relations commerciales.',
  category: 'Vente',
  date: '22 janvier 2025',
  readTime: '8 min',
  author: 'Samira Ghezali',
  authorRole: 'Formatrice commerciale - 17 ans d\'expérience terrain',
  image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663280180379/Ca9UdQGyeDkLywgwouUDBB/leadership-workshop_1d77b5c3.jpg',
  content: `
## Introduction

Après 17 ans passés sur le terrain commercial, j'ai vu passer des dizaines de "méthodes révolutionnaires" de vente. La plupart ont disparu aussi vite qu'elles sont apparues. Pourquoi ? Parce qu'elles oubliaient l'essentiel : **le client est un être humain, pas une cible**.

En 2025, les acheteurs sont plus informés, plus méfiants et plus exigeants que jamais. Les techniques de manipulation ne fonctionnent plus. Ce qui marche ? L'authenticité, l'écoute et la création de valeur réelle.

Voici les 5 techniques que j'enseigne à mes stagiaires — et qui génèrent des résultats concrets.

---

## 1. L'écoute active stratégique

**Le problème** : La plupart des commerciaux écoutent pour répondre, pas pour comprendre. Ils attendent que le client finisse de parler pour dérouler leur argumentaire.

**La technique** : Pratiquez l'écoute en 3 temps :
- **Écouter** sans interrompre (même mentalement)
- **Reformuler** pour valider votre compréhension
- **Approfondir** avec des questions ouvertes

**En pratique** : Quand un prospect dit "On a déjà un fournisseur", ne répondez pas immédiatement. Demandez : "Qu'est-ce qui fonctionne bien avec lui ? Et qu'est-ce que vous aimeriez améliorer ?"

> "J'ai compris que vendre, ce n'est pas convaincre. C'est comprendre suffisamment bien le client pour qu'il se convainque lui-même." — Retour d'un stagiaire après formation

---

## 2. La vente consultative (pas la vente conseil)

**Le problème** : Beaucoup confondent "donner des conseils" et "être consultant". Le premier est gratuit et sans engagement. Le second crée de la valeur et justifie un prix.

**La technique** : Positionnez-vous comme un expert qui diagnostique avant de prescrire :
- Posez des questions que le client ne s'est jamais posées
- Identifiez des problèmes qu'il n'avait pas conscientisés
- Proposez des solutions adaptées à SA situation

**En pratique** : Au lieu de présenter votre catalogue, commencez par un diagnostic offert de 30 minutes. Vous apprendrez plus sur le client, et il vous percevra comme un partenaire, pas comme un vendeur.

---

## 3. Le storytelling authentique

**Le problème** : Les clients sont bombardés de promesses marketing. "Leader du marché", "Solution innovante", "Résultats garantis"... Ces mots ne veulent plus rien dire.

**La technique** : Racontez des histoires vraies :
- Des cas clients similaires (avec leur permission)
- Vos propres échecs et ce que vous en avez appris
- Le parcours qui vous a mené à créer cette solution

**En pratique** : Quand un prospect hésite, ne listez pas vos avantages. Racontez l'histoire d'un client qui avait les mêmes doutes, ce qu'il a décidé, et ce qui s'est passé ensuite.

---

## 4. La transparence radicale

**Le problème** : Les commerciaux ont tendance à minimiser les inconvénients et exagérer les avantages. Les clients le sentent et perdent confiance.

**La technique** : Soyez le premier à mentionner vos limites :
- "Notre solution n'est pas adaptée si..."
- "Ce que nous faisons moins bien que X, c'est..."
- "Le risque principal, c'est..."

**En pratique** : Cette transparence désarme la méfiance. Le client se dit : "S'il me dit ça, c'est qu'il est honnête sur le reste." Paradoxalement, vous vendez plus en vendant moins.

---

## 5. Le suivi qui crée de la valeur

**Le problème** : 80% des ventes se font après le 5ème contact. Pourtant, la plupart des commerciaux abandonnent après 2 relances.

**La technique** : Chaque suivi doit apporter quelque chose :
- Un article pertinent pour leur secteur
- Une information sur un concurrent
- Une invitation à un événement
- Un retour d'expérience d'un client similaire

**En pratique** : Créez un calendrier de suivi avec du contenu de valeur. Jamais de "Je voulais juste prendre des nouvelles" ou "Avez-vous réfléchi à ma proposition ?"

---

## Conclusion : La vente éthique est la vente efficace

Ces 5 techniques ont un point commun : elles placent le client au centre. Pas par altruisme, mais parce que c'est ce qui fonctionne.

Les commerciaux qui réussissent en 2025 ne sont pas les plus agressifs ou les plus malins. Ce sont ceux qui créent de vraies relations, apportent de la valeur et méritent la confiance qu'on leur accorde.

**Vous voulez former vos équipes à ces techniques ?** Je propose des formations avec processus certifié Qualiopi, finançables par votre OPCO, basées sur 17 ans d'expérience terrain — pas sur des théories de PowerPoint.

---

*Cet article vous a été utile ? Partagez-le avec vos équipes commerciales.*
  `,
};

export default function BlogArticle() {
  const { slug } = useParams();

  useEffect(() => {
    document.title = `${articleContent.title} | Sam's Biz Solutions`;
    window.scrollTo(0, 0);
  }, []);

  // For now, we only have one article
  if (slug !== 'techniques-vente-modernes-2025') {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-32 text-center">
          <h1 className="text-2xl font-display mb-4">Article non trouvé</h1>
          <p className="text-muted-foreground mb-8">Cet article n'existe pas encore.</p>
          <Button asChild>
            <Link href="/#blog">Retour au blog</Link>
          </Button>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24">
        {/* Hero */}
        <div className="relative h-[400px] md:h-[500px] overflow-hidden">
          <img
            src={articleContent.image}
            alt={articleContent.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/50 to-transparent" />
          
          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16">
            <div className="container">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Link href="/#blog">
                  <span className="inline-flex items-center gap-2 text-cream/80 hover:text-cream mb-4 cursor-pointer">
                    <ArrowLeft size={16} />
                    Retour au blog
                  </span>
                </Link>
                
                <span className="inline-block bg-gold text-charcoal text-sm font-semibold px-3 py-1 rounded-full mb-4">
                  {articleContent.category}
                </span>
                
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-cream mb-4 max-w-4xl">
                  {articleContent.title}
                </h1>
                
                <p className="text-lg text-cream/80 max-w-2xl mb-6">
                  {articleContent.subtitle}
                </p>
                
                <div className="flex flex-wrap items-center gap-6 text-cream/70">
                  <span className="flex items-center gap-2">
                    <User size={16} />
                    {articleContent.author}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar size={16} />
                    {articleContent.date}
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock size={16} />
                    {articleContent.readTime} de lecture
                  </span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <article className="py-16">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="prose prose-lg max-w-none
                  prose-headings:font-display prose-headings:text-foreground
                  prose-h2:text-2xl prose-h2:mt-12 prose-h2:mb-6
                  prose-p:text-muted-foreground prose-p:leading-relaxed
                  prose-strong:text-foreground
                  prose-blockquote:border-l-gold prose-blockquote:bg-gold/5 prose-blockquote:py-4 prose-blockquote:px-6 prose-blockquote:rounded-r-xl prose-blockquote:not-italic
                  prose-ul:text-muted-foreground
                  prose-li:marker:text-gold
                  prose-hr:border-border"
                dangerouslySetInnerHTML={{ __html: formatMarkdown(articleContent.content) }}
              />

              {/* Author Box */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-16 p-8 bg-white rounded-2xl border border-border"
              >
                <div className="flex flex-col sm:flex-row gap-6 items-start">
                  <img 
                    src="/images/samira-ghezali.jpg" 
                    alt="Samira Ghezali"
                    className="w-20 h-20 rounded-full object-cover flex-shrink-0"
                  />
                  <div>
                    <h3 className="font-display text-xl font-semibold text-foreground mb-1">
                      {articleContent.author}
                    </h3>
                    <p className="text-gold font-medium mb-3">{articleContent.authorRole}</p>
                    <p className="text-muted-foreground mb-4">
                      Formatrice avec processus certifié Qualiopi, j'accompagne les équipes commerciales et les managers 
                      qui veulent performer sans sacrifier l'humain. Mon approche : 100% pratique, zéro bullshit.
                    </p>
                    <div className="flex gap-3">
                      <Button asChild size="sm" className="bg-gold hover:bg-gold-dark text-charcoal">
                        <a href="mailto:sbizsolutions@outlook.fr" target="_blank" rel="noopener noreferrer">
                          Réserver un diagnostic offert
                        </a>
                      </Button>
                      <Button asChild size="sm" variant="outline">
                        <a href="https://www.linkedin.com/in/samiraghezali/" target="_blank" rel="noopener noreferrer">
                          <Linkedin size={16} className="mr-2" />
                          LinkedIn
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Share */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="mt-8 flex items-center justify-between p-6 bg-background rounded-xl border border-border"
              >
                <span className="text-foreground font-medium">Cet article vous a été utile ?</span>
                <div className="flex gap-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const url = window.location.href;
                      const text = articleContent.title;
                      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
                    }}
                  >
                    <Linkedin size={16} className="mr-2" />
                    Partager sur LinkedIn
                  </Button>
                </div>
              </motion.div>

              {/* CTA */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="mt-12 p-8 bg-gradient-to-r from-gold/10 to-gold/5 rounded-2xl border border-gold/20 text-center"
              >
                <h3 className="font-display text-2xl font-semibold text-foreground mb-3">
                  Vous voulez former vos équipes à ces techniques ?
                </h3>
                <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                  Formation avec processus certifié Qualiopi, finançable par votre OPCO. 
                  Diagnostic offert de 30 minutes pour évaluer vos besoins.
                </p>
                <Button asChild size="lg" className="bg-gold hover:bg-gold-dark text-charcoal">
                  <a href="mailto:sbizsolutions@outlook.fr" target="_blank" rel="noopener noreferrer">
                    Réserver mon diagnostic offert
                  </a>
                </Button>
              </motion.div>
            </div>
          </div>
        </article>
      </main>

      <Footer />
    </div>
  );
}

// Simple markdown to HTML converter
function formatMarkdown(content: string): string {
  return content
    .replace(/^## (.*$)/gm, '<h2>$1</h2>')
    .replace(/^### (.*$)/gm, '<h3>$1</h3>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/^> (.*$)/gm, '<blockquote><p>$1</p></blockquote>')
    .replace(/^- (.*$)/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')
    .replace(/^---$/gm, '<hr />')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[hublp])/gm, '<p>')
    .replace(/(?<![>])$/gm, '</p>')
    .replace(/<p><\/p>/g, '')
    .replace(/<p>(<[hublp])/g, '$1')
    .replace(/(<\/[hublp].*>)<\/p>/g, '$1');
}
